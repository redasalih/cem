jQuery(document).ready(function(){
	
	jQuery("div.sidebar").addClass("col-xs-12 col-sm-4");
	// jQuery('.page-id-78 select#section').on('change', function(){
	// 	console.log('click');
	// });
	// console.log(jQuery('.page-id-78 div#section_chosen ul.chosen-results li').text());
	// jQuery('#section').selectpicker();
	
	 //    jQuery('.wpcf7-select').selectpicker({
		//     style: 'btn-info',
		//     size: 4
	 //    });

	

});