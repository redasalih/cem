<?php
class PagesController extends AppController {
    
    public function display() {
        
    }
}
?>