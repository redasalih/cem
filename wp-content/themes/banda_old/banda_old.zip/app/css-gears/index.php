    <link rel="stylesheet" href="<?=$site_url?>css/style.css">
    <div class="container_loading_page">
      <div class="containero">
        <img src="<?=$loading_url?>/images/Logo CEM2.png">
        <img src="http://caravaneemploi.com/wp-content/uploads/2017/01/ripple-.gif">
        <!-- <div class="gearbox">
            <div class="overlay"></div>
            <div class="gear one">
              <div class="gear-inner">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
              </div>
            </div>
            <div class="gear two">
              <div class="gear-inner">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
              </div>
            </div>
            <div class="gear three">
              <div class="gear-inner">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
              </div>
            </div>
            <div class="gear four large">
              <div class="gear-inner">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
              </div>
            </div>
        </div> -->
        <h1>Chargement ...</h1>
      </div>
    </div>
    <!--<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>-->
    <script type="text/javascript">
      jQuery(window).on("load", function() {
          jQuery('.container_loading_page').slideUp();
      });
    </script>
    <!--<script src="<?=$site_url?>js/index.js"></script>-->
