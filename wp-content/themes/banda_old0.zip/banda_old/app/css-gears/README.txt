A Pen created at CodePen.io. You can find this one at http://codepen.io/alextebbs/pen/tHhrz.

 I made these for my new portfolio site. You might be able to use this as a loading animation or something like that. I had this demo up here before but I think codepen ate it. They do look pretty tasty.
