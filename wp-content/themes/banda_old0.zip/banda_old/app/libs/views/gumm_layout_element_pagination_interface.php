<?php
interface GummLayoutElementPaginationInterface {
    public function shouldPaginate();
    public function printPaginationJs();
}
?>